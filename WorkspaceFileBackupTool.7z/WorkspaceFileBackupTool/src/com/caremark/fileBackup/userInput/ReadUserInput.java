package com.caremark.fileBackup.userInput;

import static com.caremark.fileBackup.constants.ApplicationConstant.USER_INPUT_FILE_PATH;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.util.Properties;

import org.apache.log4j.Logger;

public class ReadUserInput {

	private static final Logger logger = Logger.getLogger(ReadUserInput.class);
	private static Properties properties = new Properties();
	private static InputStream input = null;
	
	static public String getProperty(String inputProperty){
		try {
			input = new FileInputStream(USER_INPUT_FILE_PATH);
			if (input == null) {
				logger.error("Sorry, unable to find " + USER_INPUT_FILE_PATH);
				return null;
			}
			properties.load(input);
			return properties.getProperty(inputProperty);
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			logger.error(e.getMessage());
			return null;
		}
	}
	
	static public boolean createUserInputFile(){
		logger.info("Validating User Input File : "+USER_INPUT_FILE_PATH);
		try {
			File file = new File(USER_INPUT_FILE_PATH);
			if(!file.exists()){
				FileOutputStream fout = new FileOutputStream(file);
				String writeInUserFile = "user.email =\nuser.input.path =\nuser.destination.path =";
				fout.write(writeInUserFile.getBytes());
				fout.close();
				logger.info("User Input File Created Successfully. Please add your data accordingly.");
				return true;
			}
			logger.info("User Input File Available. Please add your data accordingly.");
			return true;
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			return false;
		}
	}
	
}
