package com.caremark.fileBackup.constants;

import java.io.File;

public interface ApplicationConstant {
	
	/** LOG CONSTANT'S **/
	String LOG_CONVERSION_PATTERN = "%d{dd/MM/YYYY HH:mm:ss} | %-5p | %c{1}:%L - %m%n";
	String LOG_FILE_LOCATION = "log/application.log";
	String LOG_DATE_PATTERN = "yyyy-MM-dd";
	
	/** E-MAIL CONSTANT'S **/
	String EMAIL_HOST_SERVER = "mail.smtp.host";
	String EMAIL_HOST = "azshspp04.caremarkrx.net";
	String EMAIL_ATTACHMENT_FILE_NAME = "FileBackupReport.log";
	String EMAIL_MEDIA_TYPE = "text/html";
	String EMAIL_SUBJECT_LINE = "File Backup Notification";
	String DUMMY_EMAIL = "WorkspaceBackup@cvshealth.com";
	
	String FORWARD_SLASH = "/";
	String USER_INPUT_FILE_NAME = "applicationInput.properties";
	String USER_INPUT_FILE_PATH = System.getProperty("user.dir").concat(File.separator).concat(USER_INPUT_FILE_NAME);
	
	String USER_INPUT_FILE_NOT_FOUND_MESSAGE = "File applicationInput.properties which is used for reading input data is not found. Please add the file at Utility Jar location.\nAnd please follow below Example to add records.\nuser.email =abc@cvshealth.com\nuser.input.path = H:/Rebates - Workspace/WorkspaceFileBackupTool\nuser.destination.path = Z:/BACKUP\n\n ";
	
}
