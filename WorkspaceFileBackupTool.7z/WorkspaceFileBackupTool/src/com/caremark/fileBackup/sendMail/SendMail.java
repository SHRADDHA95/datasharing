package com.caremark.fileBackup.sendMail;

import static com.caremark.fileBackup.constants.ApplicationConstant.*;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Properties;
import javax.activation.DataHandler;
import javax.activation.DataSource;
import javax.activation.FileDataSource;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Multipart;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;
import org.apache.log4j.Logger;

public class SendMail {

	private static final Logger logger = Logger.getLogger(SendMail.class);
	private static SimpleDateFormat iCalendarDateFormat = new SimpleDateFormat("yyyyMMdd'T'HHmm'00'");
	
	static private MimeBodyPart getEmailAttachment() throws MessagingException{
		MimeBodyPart messageBodyPart = new MimeBodyPart();

		DataSource source = new FileDataSource(LOG_FILE_LOCATION);
		messageBodyPart.setDataHandler(new DataHandler(source));
		messageBodyPart.setFileName(EMAIL_ATTACHMENT_FILE_NAME);
		return messageBodyPart;
	}
	
	static private MimeBodyPart getHtmlBodyContent(String emailTo) throws MessagingException{
		MimeBodyPart messageBodyPart = new MimeBodyPart();
		String userName = "";
		String user = "";
		try {
			userName = emailTo.split("@")[0].replace(".", " ");
			for(String s : userName.split(" ")){
				user+= String.valueOf(s.charAt(0)).toUpperCase().concat(s.substring(1,s.length())).concat(" ");
			}
		} catch (Exception e) {
			// TODO: handle exception
			user = "User";
		}
		String htmlContent ="<h4> Hi "+user+",</h4><p>Please find your backup log report in the attached log file.</p>" +
				"<p>Thanks for using our service, do not miss to take backup of your important files.</p><br>"+
		         "<span><b>Thanks,</b><br>Development Team</span><br><br>"+
		         "<span style='color:red'>****This is an auto-generated message, please do not reply to this email.****</span>";
		
		messageBodyPart.setContent(htmlContent, "text/html");
		return messageBodyPart;
	}
	
	static private MimeBodyPart getOutlookCalenderEvent(String emailTo) throws MessagingException{
		MimeBodyPart messageBodyPart = new MimeBodyPart();
		Calendar cal = Calendar.getInstance();
		cal.add(Calendar.DATE, 7);
		cal.add(Calendar.MINUTE, 2);
	    Date start = cal.getTime();
	    cal.add(Calendar.MINUTE, 5);
	    Date end = cal.getTime();
	     
		StringBuffer sb = new StringBuffer();
		StringBuffer buffer = sb
				.append("BEGIN:VCALENDAR\n"
						+ "PRODID:-//Microsoft Corporation//Outlook 9.0 MIMEDIR//EN\n"
						+ "VERSION:2.0\n"
						+ "METHOD:REQUEST\n"
						+ "BEGIN:VEVENT\n"
						+ "ATTENDEE;CN=\"\";ROLE=REQ-PARTICIPANT;MAILTO:"+emailTo+"\n"
						+ "ORGANIZER:MAILTO:"+emailTo+"\n"
						+ "DTSTART:" + iCalendarDateFormat.format(start) + "\n"
						+ "DTEND:" + iCalendarDateFormat.format(end) + "\n"
						//+ "LOCATION:Noida D4, FM-2\n"
						+ "TRANSP:OPAQUE\n"
						+ "SEQUENCE:0\n"
						+ "UID:040000008200E00074C5B7101A82E00800000000A0A742E5073AC5010000000000000000100\n"
						+ " 0000029606C073D82204AB6C77ACE6BC2FBE2\n"
						+ "DTSTAMP:" + iCalendarDateFormat.format(start) + "\n"
						+ "CATEGORIES:File Backup Notification\n"
						+ "DESCRIPTION:Please take the backup after 1 week.\n\n"
						+ "SUMMARY:File Backup Notification\n" + "PRIORITY:5\n"
						+ "CLASS:PUBLIC\n" + "BEGIN:VALARM\n"
						+ "TRIGGER:PT1440M\n" + "ACTION:DISPLAY\n"
						+ "DESCRIPTION:Reminder\n" + "END:VALARM\n"
						+ "END:VEVENT\n" + "END:VCALENDAR\n");
		
		messageBodyPart.setHeader("Content-Class","urn:content-classes:calendarmessage");
		messageBodyPart.setHeader("Content-ID", "calendar_message");
		messageBodyPart.setContent(buffer.toString(), "text/calendar");
		messageBodyPart.setFileName("Calender.ics");
		return messageBodyPart;
	}
	
	static public void forward(String to) throws Exception {
		Properties properties = System.getProperties();
		properties.setProperty(EMAIL_HOST_SERVER, EMAIL_HOST);
		Session session = Session.getDefaultInstance(properties);
		try {
			MimeMessage message = new MimeMessage(session);
			message.setFrom(new InternetAddress(DUMMY_EMAIL)); // From email
			message.addRecipient(Message.RecipientType.TO, new InternetAddress(to));
			message.setSubject(EMAIL_SUBJECT_LINE);

			Multipart multipart = new MimeMultipart();
			multipart.addBodyPart(getHtmlBodyContent(to));
			multipart.addBodyPart(getEmailAttachment());
			multipart.addBodyPart(getOutlookCalenderEvent(to));
			message.setContent(multipart, EMAIL_MEDIA_TYPE);

			Transport.send(message);
			logger.info("Sent E-Mail successfully....");
		} catch (MessagingException mex) {
			mex.printStackTrace();
			logger.error("Exception Occured in SendMail.java of forward : "+ mex.getMessage());
		} catch (Exception e) {
			e.printStackTrace();
			logger.error("Exception Occured in SendMail.java of forward : "+ e.getMessage());
		}
	}
}
