package com.caremark.fileBackup.sendMail;

import static com.caremark.fileBackup.constants.ApplicationConstant.*;
import java.util.Properties;
import javax.activation.DataHandler;
import javax.activation.DataSource;
import javax.activation.FileDataSource;
import javax.mail.BodyPart;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Multipart;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;
import org.apache.log4j.Logger;

public class SendMail {

	private static final Logger logger = Logger.getLogger(SendMail.class);
	
	static public void forward(String to) throws Exception{    
		  // Assuming you are sending email from localhost
	      Properties properties = System.getProperties();
	      properties.setProperty(EMAIL_HOST_SERVER, EMAIL_HOST);

	      // Get the default Session object.
	      Session session = Session.getDefaultInstance(properties);
	      try {
	    	 String userName = "";
	         MimeMessage message = new MimeMessage(session);
	         message.setFrom(new InternetAddress(DUMMY_EMAIL)); //From email
	         message.addRecipient(Message.RecipientType.TO, new InternetAddress(to));
	         //message.addRecipients(Message.RecipientType.CC, recipient);
	         message.setSubject(EMAIL_SUBJECT_LINE);
	         
	         BodyPart messageBodyPart1 = new MimeBodyPart();  
	         try {
	        	 userName = to.split("@")[0].replace(".", " ");
			} catch (Exception e) {
				// TODO: handle exception
				userName = "User";
			}
	         messageBodyPart1.setText("Hello "+userName+",\n\nPlease find file backup log report.\n\n\nThanks.\n\n\n\n\n\nNOTE : This is System Generated E-Mail. Kindly do not reply.");  
	         
	         MimeBodyPart messageBodyPart2 = new MimeBodyPart();  
	         
	         DataSource source = new FileDataSource(LOG_FILE_LOCATION);  
	         messageBodyPart2.setDataHandler(new DataHandler(source));  
	         messageBodyPart2.setFileName(EMAIL_ATTACHMENT_FILE_NAME);  
	          
	         // create Multipart object and add MimeBodyPart objects to this object      
	         Multipart multipart = new MimeMultipart();  
	         multipart.addBodyPart(messageBodyPart1);  
	         multipart.addBodyPart(messageBodyPart2);   
	         
	         message.setContent(multipart,EMAIL_MEDIA_TYPE);  
	         
	         Transport.send(message);
	         logger.info("Sent E-Mail successfully....");
	      }catch (MessagingException mex) {
	         mex.printStackTrace();
	         logger.error("Exception Occured in SendMail.java of forward : "+mex.getMessage());
	      }catch(Exception e){
	    	  e.printStackTrace();
	    	  logger.error("Exception Occured in SendMail.java of forward : "+e.getMessage());
	      }
	}
	
	
}

