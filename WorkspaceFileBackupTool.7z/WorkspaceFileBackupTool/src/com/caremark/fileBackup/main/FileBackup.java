package com.caremark.fileBackup.main;

import static com.caremark.fileBackup.constants.ApplicationConstant.*;
import java.io.FileNotFoundException;
import java.io.IOException;
import javax.naming.directory.InvalidAttributesException;
import org.apache.log4j.Logger;
import com.caremark.fileBackup.createBackup.CreateFileBackup;
import com.caremark.fileBackup.logging.ApplicationLogging;
import com.caremark.fileBackup.readUserInput.ReadUserInput;
import com.caremark.fileBackup.sendMail.SendMail;
import com.caremark.fileBackup.validations.Validate;

public class FileBackup {

	private static final Logger logger = Logger.getLogger(FileBackup.class);
	private static CreateFileBackup createFileBackup = null;
	
	static {
		/** Setting Application Logging Properties*/
		ApplicationLogging.configLogging();
	}
	
	private static CreateFileBackup getInstance(){
		if(createFileBackup == null){
			createFileBackup = new CreateFileBackup();
		}
		return createFileBackup;
	}
	
	private static void sendEmail(String emailTo) throws Exception{
		try {
			SendMail.forward(emailTo);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			logger.error("Exception Occured in FileBackup.java of sendEmail : "+e.getMessage());
		}
	}
	/**
	 * @param args
	 * @throws Exception 
	 */
	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		logger.info("File Backup Utility Started...");
		if(validateUserInputs()){
			String sourcePath = ReadUserInput.getProperty("user.input.path");
			String destinationPath = ReadUserInput.getProperty("user.destination.path");
			
			getInstance().copyLastModifiedFile(sourcePath,destinationPath);
			
			logger.info("Total Number of Modified Files are : "+CreateFileBackup.TOTAL_MODIFIED_FILES);
			FileBackup.sendEmail(ReadUserInput.getProperty("user.email"));
		}
		
	}

	private static boolean validateUserInputs(){
		try {
			if(!ReadUserInput.isUserInputFileAvailable(USER_INPUT_FILE_PATH)){
				if(!ReadUserInput.createUserInputFile(USER_INPUT_FILE_PATH)){
					throw new FileNotFoundException(INPUT_FILE_CREATION_EXPEPTION_MSG);
				}
			}
			
			if(Validate.isEmptyString(ReadUserInput.getProperty("user.email")).equals(BLANK_STRING)){
				throw new NullPointerException(BLANK_EMAIL_ADDRESS);
			}
			if(!Validate.isValidateEmail(ReadUserInput.getProperty("user.email"))){
				throw new InvalidAttributesException(INVALID_EMAIL);
			}
			if(Validate.isEmptyString(ReadUserInput.getProperty("user.input.path")).equals(BLANK_STRING)){
				throw new NullPointerException(BLANK_SOURCE_PATH);
			}
			if(Validate.isEmptyString(ReadUserInput.getProperty("user.destination.path")).equals(BLANK_STRING)){
				throw new NullPointerException(BLANK_DESTINATION_PATH);
			}
			return true;
		} catch (Exception e) {
			// TODO: handle exception
			logger.error(e.getMessage());
			return false;
		}
	}
	
}
