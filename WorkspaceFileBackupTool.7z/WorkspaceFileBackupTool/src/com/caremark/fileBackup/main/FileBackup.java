package com.caremark.fileBackup.main;

import static com.caremark.fileBackup.constants.ApplicationConstant.*;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import javax.naming.directory.InvalidAttributesException;
import org.apache.log4j.Logger;
import com.caremark.fileBackup.createBackup.CreateFileBackup;
import com.caremark.fileBackup.logging.ApplicationLogging;
import com.caremark.fileBackup.sendMail.SendMail;
import com.caremark.fileBackup.userInput.ReadUserInput;
import com.caremark.fileBackup.validations.Validate;

public class FileBackup {

	private static final Logger logger = Logger.getLogger(FileBackup.class);
	private static CreateFileBackup createFileBackup = null;
	
	static {
		/** Setting Application Logging Properties*/
		ApplicationLogging.configLogging();
	}
	
	private static CreateFileBackup getInstance(){
		if(createFileBackup == null){
			createFileBackup = new CreateFileBackup();
		}
		return createFileBackup;
	}
	
	private static void sendEmail(String emailTo) throws Exception{
		try {
			SendMail.forward(emailTo);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			logger.error("Exception Occured in FileBackup.java of sendEmail : "+e.getMessage());
		}
	}
	/**
	 * @param args
	 * @throws Exception 
	 */
	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		logger.info("File Backup Utility Started...");
		if(validateUserInputs()){
			String sourcePath = ReadUserInput.getProperty("user.input.path");
			String destinationPath = ReadUserInput.getProperty("user.destination.path");
			
			getInstance().copyLastModifiedFile(sourcePath,destinationPath);
			
			logger.info("Total Number of Modified Files are : "+CreateFileBackup.TOTAL_MODIFIED_FILES);
			FileBackup.sendEmail(ReadUserInput.getProperty("user.email"));
		}
		
	}

	private static boolean validateUserInputs(){
		try {
			if(!ReadUserInput.createUserInputFile()){
				throw new FileNotFoundException("Unable to create User Input File applicationInput.properties.");
			}
			if(!new File(USER_INPUT_FILE_PATH).exists()){
				throw new FileNotFoundException(USER_INPUT_FILE_NOT_FOUND_MESSAGE);
			}
			if(!Validate.isValidateEmail(ReadUserInput.getProperty("user.email"))){
				throw new InvalidAttributesException("Invalid User E-Mail.");
			}
			if(Validate.isEmptyString(ReadUserInput.getProperty("user.email")).equals("")){
				throw new NullPointerException("User E-Mail Can not be Blank.");
			}
			if(Validate.isEmptyString(ReadUserInput.getProperty("user.input.path")).equals("")){
				throw new NullPointerException("Source Directory Path Can not be Blank.");
			}
			if(Validate.isEmptyString(ReadUserInput.getProperty("user.destination.path")).equals("")){
				throw new NullPointerException("Destination Directory Path Can not be Blank.");
			}
			return true;
		} catch (Exception e) {
			// TODO: handle exception
			logger.error(e.getMessage());
			return false;
		}
	}
	
}
