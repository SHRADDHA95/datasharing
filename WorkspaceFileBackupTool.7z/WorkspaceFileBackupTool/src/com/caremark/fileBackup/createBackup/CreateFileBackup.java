package com.caremark.fileBackup.createBackup;

import static com.caremark.fileBackup.constants.ApplicationConstant.FORWARD_SLASH;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Calendar;
import java.util.Date;

import org.apache.commons.io.FileUtils;
import org.apache.log4j.Logger;

public class CreateFileBackup {

	private static final Logger logger = Logger.getLogger(CreateFileBackup.class);
	public static int TOTAL_MODIFIED_FILES = 0;
	
	@SuppressWarnings("deprecation")
	private Calendar getCalender(long lastModified){
		Calendar calendar = Calendar.getInstance();
		calendar.setTime(new Date(lastModified));

		calendar.setTime(new Date(this.getDate(calendar)));
		return calendar;
	}
	
	public String getDate(Calendar calendar){
		StringBuilder date = new StringBuilder();
		date.append(calendar.get(Calendar.MONTH) + 1);
		date.append(FORWARD_SLASH);
		date.append(calendar.get(Calendar.DATE));
		date.append(FORWARD_SLASH);
		date.append(calendar.get(Calendar.YEAR));
		
		return date.toString();
	}
	
	private static void copyFilesToDirectory(String sourceDirectoryPath,String destinationDirectoryPath) 
			throws IOException{
		logger.info("SOURCE PATH : "+sourceDirectoryPath);
		FileUtils.copyFileToDirectory(new File(sourceDirectoryPath), new File(destinationDirectoryPath));
		logger.info("FILE COPYIED SUCCESSFULLY : "+destinationDirectoryPath);
	}
	
	private String createDirectory(String destinationDirectoryPath) throws IOException{
		File file = new File(destinationDirectoryPath);
		if(!file.exists()){
			file.mkdirs();
		}else{
			/*String directoryLastModifiedDate = getDate(getCalender(file.lastModified()));
			logger.debug("LAST MODIFIED DIRECTORY : "+directoryLastModifiedDate+" : "+destinationDirectoryPath);*/
			
			Calendar calendar = Calendar.getInstance();
			calendar.add(Calendar.DATE, -7);
			
			/*logger.debug("dateBeforeOneWeek : "+getDate(getCalender(calendar.getTimeInMillis())));
			
			logger.debug("STATUS : "+getCalender(file.lastModified()).equals(getCalender(calendar.getTimeInMillis()))+"\t"
			+getCalender(calendar.getTimeInMillis()).before(getCalender(file.lastModified()))+
			"\t"+getCalender(calendar.getTimeInMillis()).after(getCalender(file.lastModified())));
			*/
			if(getCalender(file.lastModified()).equals(getCalender(calendar.getTimeInMillis()))){
				logger.debug("Deleting Old 1 Week Directory : "+destinationDirectoryPath);
				deleteDirectory(file);
				createDirectory(destinationDirectoryPath);
			}
		}
		return destinationDirectoryPath;
	}
	
	private void deleteDirectory(File directoryToBeDeleted) throws IOException {
		FileUtils.deleteDirectory(directoryToBeDeleted);
	}
	
	public void copyLastModifiedFile(String sourceDirectoryPath,String destinationDirectoryPath){
		try {
			File sourceLocation = new File(sourceDirectoryPath);
			if(!sourceLocation.exists()){
				logger.error("Invalid Source Path : "+sourceDirectoryPath);
				throw new FileNotFoundException("Invalid Source Path");
			}
			File[] directoryFilesList = sourceLocation.listFiles();
			if(directoryFilesList.length == 0){
				logger.warn("No Files Found in Directory : "+sourceDirectoryPath);
			}else{
				for(File sourceFile : directoryFilesList){
					if(sourceFile.isDirectory()){
						copyLastModifiedFile(sourceFile.getAbsolutePath(),destinationDirectoryPath);
					}else{
						if(getCalender(sourceFile.lastModified()).equals(getCalender(Calendar.getInstance().getTimeInMillis()))){
							TOTAL_MODIFIED_FILES++;
							String tempDestPath = destinationDirectoryPath.concat(sourceFile.getParent().substring(2, sourceFile.getParent().length()));
							copyFilesToDirectory(sourceFile.getAbsolutePath(),createDirectory(tempDestPath));
							//copyFilesToDirectory(sourceFile.getAbsolutePath(),createDirectory(sourceFile.getParent().replaceFirst("H", "Z")));
						}
					}
				}
			}
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			logger.error("Exception Occured in CreateFileBackup.java of copyLastModifiedFile : "+e.getMessage());
		}
	}
	
}
