package com.caremark.fileBackup.logging;

import org.apache.log4j.ConsoleAppender;
import org.apache.log4j.DailyRollingFileAppender;
import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.apache.log4j.PatternLayout;
import static com.caremark.fileBackup.constants.ApplicationConstant.*;

public class ApplicationLogging {
	
	private static final Logger logger = Logger.getLogger(ApplicationLogging.class);
	
	public static void configLogging(){
		try {
			// creates pattern layout
	        PatternLayout layout = new PatternLayout();
	        layout.setConversionPattern(LOG_CONVERSION_PATTERN);
	 
	        // creates daily rolling file appender
	        DailyRollingFileAppender rollingAppender = new DailyRollingFileAppender();
	        rollingAppender.setAppend(false);
	        rollingAppender.setImmediateFlush(true);
	        rollingAppender.setFile(LOG_FILE_LOCATION);
	        rollingAppender.setDatePattern("'.'"+LOG_DATE_PATTERN);
	        rollingAppender.setLayout(layout);
	        rollingAppender.activateOptions();
	 
	        // creates daily rolling console appender
	        ConsoleAppender consoleAppender = new ConsoleAppender();
	        consoleAppender.setImmediateFlush(true);
	        consoleAppender.setTarget("System.out");
	        consoleAppender.setLayout(layout);
	        consoleAppender.activateOptions();
	        
	        // configures the root logger
	        Logger rootLogger = Logger.getRootLogger();
	        rootLogger.setLevel(Level.DEBUG);
	        rootLogger.addAppender(rollingAppender);
	        rootLogger.addAppender(consoleAppender);
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			logger.error("Exception Occured in ApplicationLogging.java of forward : "+e.getMessage());
		}
	}
}
