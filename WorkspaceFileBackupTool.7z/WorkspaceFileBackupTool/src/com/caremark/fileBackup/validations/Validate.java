package com.caremark.fileBackup.validations;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Validate {
	
	private static final String EMAIL_REGEX = "^[\\w-\\+]+(\\.[\\w]+)*@[\\w-]+(\\.[\\w]+)*(\\.[a-z]{2,})$";
	
	public static boolean isValidateEmail(String email) {
		Pattern pattern = Pattern.compile(EMAIL_REGEX, Pattern.CASE_INSENSITIVE);
		Matcher matcher = pattern.matcher(email);
		return matcher.matches();
	}
	
	public static String isEmptyString(String value){
		return value == null ? "" : value.trim().toString();
	}
	
	
}
