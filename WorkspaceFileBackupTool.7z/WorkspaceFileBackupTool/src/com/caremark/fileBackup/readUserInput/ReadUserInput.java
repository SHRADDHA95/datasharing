package com.caremark.fileBackup.readUserInput;

import static com.caremark.fileBackup.constants.ApplicationConstant.USER_INPUT_FILE_PATH;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.util.Properties;

import org.apache.log4j.Logger;

public class ReadUserInput {

	private static final Logger logger = Logger.getLogger(ReadUserInput.class);
	private static Properties properties = new Properties();
	private static InputStream input = null;
	
	static public String getProperty(String inputProperty){
		try {
			input = new FileInputStream(USER_INPUT_FILE_PATH);
			if (input == null) {
				logger.error("Sorry, unable to find " + USER_INPUT_FILE_PATH);
				return null;
			}
			properties.load(input);
			return properties.getProperty(inputProperty);
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			logger.error(e.getMessage());
			return null;
		}
	}
	
	static public boolean isUserInputFileAvailable(String userInputFilePath){
		return new File(userInputFilePath).exists() ? true : false;
	}
	
	static public boolean createUserInputFile(String userInputFilePath){
		try {
			File file = new File(userInputFilePath);
			FileOutputStream fout = new FileOutputStream(file);
			String writeInUserFile = "user.email =\nuser.input.path =\nuser.destination.path =";
			fout.write(writeInUserFile.getBytes());
			fout.close();
			logger.info("\n\nUser Input File Created Successfully applicationInput.properties. Please add your data accordingly. And Run Utility Again.Please follow below Example to add records.\nuser.email =abc@cvshealth.com\nuser.input.path = H:/Rebates - Workspace/WorkspaceFileBackupTool\nuser.destination.path = Z:/BACKUP\n\n");
			return true;
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			return false;
		}
	}
	
}
