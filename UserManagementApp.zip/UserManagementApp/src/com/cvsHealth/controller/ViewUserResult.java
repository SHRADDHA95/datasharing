package com.cvsHealth.controller;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.List;

import org.json.simple.parser.ParseException;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.cvsHealth.AppData.JSONReader;
import com.cvsHelath.Model.User;

@Controller
@RequestMapping(value = "userList")
public class ViewUserResult {

	/*
	 * @RequestMapping public String userResult() {
	 * 
	 * System.out.println("Inside userResult Controller"); return "userList";
	 * 
	 * }
	 */

	@RequestMapping
	public ModelAndView listEmployee() throws FileNotFoundException, IOException, ParseException {
		System.out.println("ViewUserResult Controller");
		JSONReader reader = new JSONReader();
		List<User> valFromJSON = reader.readFromJSON();
		ModelAndView map = new ModelAndView("userList");
		map.addObject("lists", valFromJSON);

		return map;
	}

}
