package com.cvsHealth.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping(value = "/countryList")
public class CountryController {

	@RequestMapping
	public String displayCountries() {

		System.out.println("Inside Country Controller");
		return "countryList";
	}

}
