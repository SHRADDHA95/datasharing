package com.cvsHealth.controller;

import java.io.FileNotFoundException;
import java.io.IOException;

import org.json.simple.parser.ParseException;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.cvsHealth.AppData.JSONWriter;
import com.cvsHelath.Model.User;

@Controller
@RequestMapping(value = "/register/")
public class RegisterController {
    
	
	
	@ModelAttribute("userForm")
	public User user() {
		return new User();
	}

	@RequestMapping(value = "save", method = RequestMethod.POST)
	public String processRegistration(User user, Model model) throws FileNotFoundException, IOException, ParseException {

		// implement your own registration logic here...

		// for testing purpose:
		JSONWriter obj = new JSONWriter();
		obj.writeIntoJSON(user);
		System.out.println("username: " + user.getUsername());
		System.out.println("password: " + user.getPassword());
		System.out.println("email: " + user.getEmail());
		System.out.println("birth date: " + user.getDOB());
		model.addAttribute("userForm", user);
		return "RegistrationSuccess";
	}
}