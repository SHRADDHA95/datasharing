package com.cvsHealth.AppData;

import static com.cvsHealth.constants.ApplicationConstants.USER_INFORMATION_JSON;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.json.simple.parser.ParseException;

import com.cvsHelath.Model.User;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

public class JSONReader {

	public List<User> readFromJSON() throws FileNotFoundException, IOException, ParseException {
		BufferedReader reader = new BufferedReader(new FileReader(USER_INFORMATION_JSON));
		Gson gson = new GsonBuilder().create();
		User[] people = gson.fromJson(reader, User[].class);

		

		List<User> list = new ArrayList<>();
		if (people != null && people.length > 0) {
			for (int i = 0; i < people.length; i++) {
				//System.out.println(people[i]);
				list.add(people[i]);
			}
		}
		return list;
	}
}