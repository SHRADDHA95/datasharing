package com.cvsHealth.constants;

public interface ApplicationConstants {

	/** user information --json file **/

	String USER_INFORMATION_JSON = "D:\\STS_Workspace\\UserManagementApp\\WebContent\\WEB-INF\\resources\\userInfo.json";
	// String USER_INPUT_FILE_PATH =
	// System.getProperty("user.dir").concat(File.separator).concat(USER_INFORMATION_FILE);

}
